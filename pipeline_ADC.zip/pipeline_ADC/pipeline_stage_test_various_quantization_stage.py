#!/usr/bin/env python
# -- Ayan Chakrabarti <ayan@wustl.edu>

import numpy as np

############## Inverter characteristics
#########################################################################################

VCMi = 0.533225
#VCM = 0.8
VCM = 0.75

#VDD = 2*VCMi
VDD_H = 2.0
alpha_0 = VDD_H

OFFS = 0.5 * VDD_H - VCMi
FNAME = 'VTC_1_5.csv'
#FNAME = 's8_16h64_load_new_size5.csv'
#FNAME = 's6_8h12_load_new_size5.csv'
COL = 'M'; SKIP = 2
XMIN = 0.001225; XMAX = 1.501225; XSTEP = 0.002

reso_f = 16
reso_r = 16

C0 = 0.0005


class VTC:
    def __init__(self):
        lines = open(FNAME).readlines()[SKIP:]
        data = [[float(x) if len(x) > 0 else 0.0 for x in l.split(',')] for l in lines]
        data = np.float32(data)

        self.GT = data[:, [0, ord(COL) - ord('A')]]

        data = data[:, ord(COL) - ord('A')]

        assert (data.shape[0] == int((XMAX - XMIN) / XSTEP) + 0)

        slope = (data[1:] - data[:-1]) / XSTEP
        offs = data[:-1] - slope * (XMIN + np.arange(slope.shape[0]) * XSTEP)

        self.slope = slope
        self.offs = offs
        self.midx = slope.shape[0] - 1

    def act(self, x):
        x = np.minimum(XMAX, np.maximum(XMIN, x))
        idx = np.floor((x - XMIN) / XSTEP)
        idx = np.int64(np.minimum(self.midx, np.maximum(0., idx)))

        return self.slope[idx] * x + self.offs[idx]


vtc = VTC()


#########################################################################################


#########################################################################################
class Flash_Circuit:
    def __init__(self, fname):
        data = np.load(fname)
        self.data = data


        w0 = data['w0']
        b0 = data['b0']
        p0, n0 = np.maximum(0., w0), np.maximum(0., -w0)

        p0 = np.round(p0/(0.20*VDD_H) * (2 ** reso_f-1)) / ((2**reso_f - 1)) * (0.20 * VDD_H)
        n0 = np.round(n0/(0.20*VDD_H) * (2 ** reso_f-1)) / ((2**reso_f - 1)) * (0.20 * VDD_H)

        bmax = VDD_H - np.sum(np.abs(w0), axis=0)


        ypb1 = b0 - np.sum(np.abs(n0), axis=0)
        ypb = np.where(np.where(ypb1 > bmax, bmax, ypb1) < 0, 0, ypb1)


        ynb1 = VDD_H - b0 - np.sum(np.abs(p0), axis=0)
        ynb = np.where(np.where(ynb1 > bmax, bmax, ynb1) < 0, 0, ynb1)


        p0, n0 = p0/1, n0/1

        G0SA = p0 * C0
        G0SB = n0 * C0
        G0BAP = ypb * C0 / VDD_H
        G0BBP = C0 - G0SA - G0SB - G0BAP
        G0BBN = ynb * C0 / VDD_H
        G0BAN = C0 - G0SA - G0SB - G0BBN


        self.G0SA = G0SA
        self.G0SB = G0SB
        self.G0BAP = G0BAP
        self.G0BBP = G0BBP
        self.G0BBN = G0BBN
        self.G0BAN = G0BAN

        self.BIAS0 = VDD_H


        w1 = data['wf']
        b1 = data['bf']
        div = np.sum(np.abs(w1), 0)
        w1 = w1 / (2 * div)
        b1 = b1 / (2 * div)


        pf, nf = np.maximum(0., w1), np.maximum(0., -w1)
        pf = np.round(pf / (np.maximum(np.max(pf), np.max(nf))) * (2 ** reso_f - 1)) / ((2 ** reso_f - 1)) * np.maximum(
            np.max(pf), np.max(nf))
        nf = np.round(nf / (np.maximum(np.max(pf), np.max(nf))) * (2 ** reso_f - 1)) / ((2 ** reso_f - 1)) * np.maximum(
            np.max(pf), np.max(nf))


        G1SA = pf * C0
        G1SB = nf * C0
        VM_1 = VDD_H / 2
        BIAS1 = VDD_H

        b1crossbar = np.matmul((-VCM - OFFS) * np.ones(b0.shape[0]), (pf + nf)) + b1 + VM_1
        G1BA = b1crossbar * C0 / BIAS1
        G1BB = C0 - np.sum(G1SA, 0) - np.sum(G1SB, 0) - G1BA


        self.nBits = b1.shape[0]
        self.nHidden = b0.shape[0]


        self.G1SA = G1SA
        self.G1SB = G1SB
        self.G1BA = G1BA
        self.G1BB = G1BB
        self.BIAS1 = BIAS1


    def encode(self, x):

        x = np.reshape(x, [-1, 1])

        G0SA = self.G0SA; G0SB = self.G0SB; G0BAP = self.G0BAP; G0BBP = self.G0BBP; G0BAN = self.G0BAN; G0BBN = self.G0BBN;BIAS0 = self.BIAS0
        G1SA = self.G1SA; G1SB = self.G1SB; G1BA = self.G1BA; G1BB = self.G1BB; BIAS1 = self.BIAS1

        p0, n0 = G0SA /(G0SA + G0SB + G0BAP + G0BBP), G0SB /(G0SA + G0SB + G0BAN + G0BBN)
        ypb,ynb = BIAS0 * G0BAP/(G0SA + G0SB + G0BAP + G0BBP), BIAS0 * G0BBN/(G0SA + G0SB + G0BAN + G0BBN)

        yp = np.matmul(x, p0) + np.matmul((VDD_H - x), n0) + ypb
        yn = np.matmul((VDD_H - x), p0) + np.matmul(x, n0) + ynb

        yp = vtc.act(yp - OFFS) + OFFS
        yn = vtc.act(yn - OFFS) + OFFS

        pf, nf = G1SA / (np.sum(G1SA,0) + np.sum(G1SB,0) + G1BA + G1BB) , G1SB / (np.sum(G1SA,0) +np.sum(G1SB,0) + G1BA + G1BB)
        b1 = BIAS1 * G1BA / (np.sum(G1SA,0) +np.sum(G1SB,0) + G1BA + G1BB)
        y = np.matmul(yp, pf) + np.matmul(yn, nf) + b1

        return np.float32(y > BIAS1/2)

#################################################




class Residual_Circuit:
    def __init__(self,fname):
        data = np.load(fname)
        self.data = data

        w0 = data['w0']
        b0 = data['b0']
        p0, n0 = np.maximum(0., w0), np.maximum(0., -w0)

        p0 = np.round(p0/(0.10*VDD_H) * (2 ** reso_r - 1)) / ((2 ** reso_r - 1)) * (0.10 * VDD_H)
        n0 = np.round(n0/(0.10*VDD_H) * (2 ** reso_r - 1)) / ((2 ** reso_r - 1)) * (0.10 * VDD_H)

        bmax = VDD_H - np.sum(np.abs(w0), axis=0)

        ypb1 = b0 - np.sum(np.abs(n0), axis=0)
        ypb = np.where(np.where(ypb1 > bmax, bmax, ypb1) < 0, 0, ypb1)

        ynb1 = VDD_H - b0 - np.sum(np.abs(p0), axis=0)
        ynb = np.where(np.where(ynb1 > bmax, bmax, ynb1) < 0, 0, ynb1)

        p0, n0 = p0 / 1, n0 / 1

        G0SA = p0 * C0
        G0SB = n0 * C0
        G0BAP = ypb * C0 / VDD_H
        G0BBP = C0 - np.sum(G0SA,0) - np.sum(G0SB,0) - G0BAP
        G0BBN = ynb * C0 / VDD_H
        G0BAN = C0 - np.sum(G0SA,0) - np.sum(G0SB,0) - G0BBN


        self.G0SA = G0SA
        self.G0SB = G0SB
        self.G0BAP = G0BAP
        self.G0BBP = G0BBP
        self.G0BBN = G0BBN
        self.G0BAN = G0BAN

        self.BIAS0 = VDD_H


        w1 = 0.86*data['wf']
        b1 = 0.86*data['bf']  ### can be adjusted


        pf, nf = np.maximum(0., w1), np.maximum(0., -w1)
        pf = np.round(pf / (np.maximum(np.max(pf), np.max(nf))) * (2 ** reso_r - 1)) / ((2 ** reso_r - 1)) * np.maximum(
            np.max(pf), np.max(nf))
        nf = np.round(nf / (np.maximum(np.max(pf), np.max(nf))) * (2 ** reso_r - 1)) / ((2 ** reso_r - 1)) * np.maximum(
            np.max(pf), np.max(nf))



        G1SA = pf * C0
        G1SB = nf * C0
        VM_1 = VDD_H/2
        BIAS1 = VDD_H

        b1crossbar = np.matmul((-VCM-OFFS)*np.ones(b0.shape[0]), (pf+nf)) + b1 + VM_1
        G1BA = b1crossbar * C0 /BIAS1
        G1BB = C0 - np.sum(G1SA,0) - np.sum(G1SB,0) - G1BA


        self.nBits = b1.shape[0]
        self.nHidden = b0.shape[0]

        self.G1SA = G1SA
        self.G1SB = G1SB
        self.G1BA = G1BA
        self.G1BB = G1BB
        self.BIAS1 = BIAS1
        self.VM_1 = VM_1

    def encode(self,x):
        #x = np.reshape(x,[-1,1])

        G0SA = self.G0SA; G0SB = self.G0SB; G0BAP = self.G0BAP; G0BBP = self.G0BBP; G0BAN = self.G0BAN; G0BBN = self.G0BBN;BIAS0 = self.BIAS0
        G1SA = self.G1SA; G1SB = self.G1SB; G1BA = self.G1BA; G1BB = self.G1BB; BIAS1 = self.BIAS1; VM_1 = self.VM_1

        p0, n0 = G0SA /(np.sum(G0SA,0) + np.sum(G0SB,0) + G0BAP + G0BBP), G0SB /(np.sum(G0SA,0) + np.sum(G0SB,0) + G0BAN + G0BBN)
        ypb,ynb = BIAS0 * G0BAP/(np.sum(G0SA,0) + np.sum(G0SB,0) + G0BAP + G0BBP), BIAS0 * G0BBN/(np.sum(G0SA,0) + np.sum(G0SB,0) + G0BAN + G0BBN)

        yp = np.matmul(x, p0) + np.matmul((VDD_H - x), n0) + ypb
        yn = np.matmul((VDD_H - x), p0) + np.matmul(x, n0) + ynb

        yp = vtc.act(yp - OFFS) + OFFS
        yn = vtc.act(yn - OFFS) + OFFS

        pf, nf = G1SA / (np.sum(G1SA,0) + np.sum(G1SB,0) + G1BA + G1BB) , G1SB / (np.sum(G1SA,0) +np.sum(G1SB,0) + G1BA + G1BB)
        b1 = BIAS1 * G1BA / (np.sum(G1SA,0) +np.sum(G1SB,0) + G1BA + G1BB)
        y = np.matmul(yp, pf) + np.matmul(yn, nf) + b1
        return y



import sys

ckt_f_1 = Flash_Circuit(sys.argv[1])
ckt_r_1 = Residual_Circuit(sys.argv[2])

tm =  np.linspace(0.,2*np.pi,2**18)
signal = VDD_H/2 + 0.4 * np.sin(tm)

signal_1 = signal

pipeline_stage = 3
quant = np.zeros(len(signal_1))

### only using 1-bit stage

for i in range(pipeline_stage):
    sig_in_f_1 = signal_1
    quant_f_1 = 2 * ckt_f_1.encode(sig_in_f_1)
    sig_in_r_1 = np.column_stack((sig_in_f_1, quant_f_1))
    signal_1 = ckt_r_1.encode(sig_in_r_1)
    #signal_1 = quant_r_1
    quant = np.column_stack((quant, quant_f_1))


### using 2-bit stage
ckt_f_2 = Flash_Circuit(sys.argv[3])
ckt_r_2 = Residual_Circuit(sys.argv[4])

sig_in_f_2 = signal_1
quant_f_2 = 2 * ckt_f_2.encode(sig_in_f_2)
sig_in_r_2 = np.column_stack((sig_in_f_2, quant_f_2))
signal_2= ckt_r_2.encode(sig_in_r_2)
#signal_1 = quant_r
quant = np.column_stack((quant, quant_f_2))
### end

### using 3-bit stage
ckt_f_3 = Flash_Circuit(sys.argv[5])
sig_in_f_3 = signal_2
quant_f_3 = 2 * ckt_f_3.encode(sig_in_f_3)
quant = np.column_stack((quant, quant_f_3))

### end

wts = 2**np.float32(np.arange(pipeline_stage*ckt_f_1.nBits+1+ckt_f_2.nBits+ckt_f_3.nBits))
val = np.float32(np.sum(wts*quant,1)) # Binary Representation

# Best decoder
vs = np.unique(val)
val2 = val.copy()
for v in vs:
    o = np.mean(signal[val2 == v])
    val[val2 == v] = o

gt = signal

mse = np.mean((gt-val)**2)
SINAD = 10*np.log10(np.var(gt) + mse) - 10*np.log10(mse)
ENOB = (SINAD-1.76)/6.02
print("ENOB = %.2f (%d)" % (ENOB,(pipeline_stage * ckt_r_1.nBits)))



if len(sys.argv) == 7:
    import matplotlib as mp

    mp.use('Agg')
    import matplotlib.pyplot as plt

    #plt.set_size_inches(20,10)
    plt.plot(tm, gt, '-k', linewidth=2.5)
    plt.plot(tm, val, '-r', linewidth=1.5)

    plt.ylim([0.5, 1.5])
    plt.title("%d Bits, %d Hidden Neurons: ENOB = %.2f" % (ckt_r_1.nBits,ckt_r_1.nHidden,ENOB))
    plt.savefig(sys.argv[6],dpi=120)