#!/usr/bin/env python
# -- Ayan Chakrabarti <ayan@wustl.edu>

import numpy as np

import sys

import math
nBits1 = 10

a = []
# tm = np.linspace(0.,2*np.pi,2**15)
#sig = np.linspace(0., 0.8-1e-4, 2 ** 15)

sig = np.linspace(2**(-10),1,2**15) ### For the first stage training
sig1 = sig

log_encoding = (np.log2(sig) + 10)/10

out = np.int64(np.round(log_encoding*(2**nBits1-1)))

# Binary Representation

# Best decoder
vs = np.unique(out)
val2 = out.copy()
val3 = out.copy()
for v in vs:
    o = np.mean(sig1[val2 == v])
    a.append(o)
    out[val2 == v] = o
    val3[val2 == v] = o

gt = sig1

a = np.array(a)
#log_encoding = (2**sig - 1)





if len(sys.argv) == 2:
    import matplotlib as mp

    mp.use('Agg')
    import matplotlib.pyplot as plt

    # plt.plot(tm,gt,'-g',linewidth=1.5)
    plt.plot(sig,log_encoding, '-k', linewidth=2.5)
    plt.plot(sig, log_encoding, '-r', linewidth=1.5)
    plt.ylim([-0.1, 1.2])
    #    plt.title("%d Bits, %d Hidden Neurons: ENOB = %.2f" % (ckt.nBits,ckt.nHidden,ENOB))
    plt.savefig(sys.argv[1], dpi=120)
