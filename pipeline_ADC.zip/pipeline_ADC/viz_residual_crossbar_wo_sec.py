#!/usr/bin/env python
#-- Ayan Chakrabarti <ayan@wustl.edu>
#-- Weidong Cao <weidong.cao@wustl.edu>

import numpy as np

VDD=1.4
C0 = 0.0005
C1 = 0.00005
alpha_0 = VDD/1
VCMi=0.4729492
VCM =0.6
VCMO = 0.7605
OFFS=0.5*VDD-VCMi
VMAX = 1.1999
VMIN = -0.0000508

############## Inverter characteristics
#########################################################################################

def makeCode(nb1, nb2):
    levels = 2 ** nb1
    lchg = np.zeros(nb2)

    def tostr(b):
        return ' '.join([str(int(i)) for i in b])

    codes = [np.zeros(nb2)]
    strs = [tostr(codes[0])]

    for id in range(1, levels):
        idx = np.argsort(lchg)
        for k in range(len(idx)):
            nb = codes[-1].copy()
            nb[idx[k]] = 1 - nb[idx[k]]
            st = tostr(nb)
            if st not in strs:
                lchg[idx[k]] = id
                codes.append(nb)
                strs.append(st)
                break
        assert len(strs) == id + 1

    return np.stack(codes, 0)



FNAME = 's8_16h64_load_new_size5.csv'
#FNAME = 's6_8h12_load_new_size5.csv'
COL = 'M'; SKIP = 2; XMIN=0.00295;XMAX=1.20095;XSTEP=0.002
class VTC:
    def __init__(self):
        lines = open(FNAME).readlines()[SKIP:]
        data = [[float(x) if len(x) > 0 else 0.0 for x in l.split(',')] for l in lines]
        data=np.float32(data)

        self.GT = data[:,[0,ord(COL)-ord('A')]]
        
        data = data[:,ord(COL)-ord('A')]

        assert(data.shape[0] == int((XMAX-XMIN)/XSTEP)+1)

        slope = (data[1:]-data[:-1])/XSTEP
        offs = data[:-1] - slope*(XMIN+np.arange(slope.shape[0])*XSTEP)

        self.slope = slope
        self.offs = offs
        self.midx = slope.shape[0]-1

    def act(self,x):
        x = np.minimum(XMAX,np.maximum(XMIN,x))
        idx = np.floor((x - XMIN)/XSTEP)
        idx = np.int64(np.minimum(self.midx,np.maximum(0.,idx)))

        return self.slope[idx]*x+self.offs[idx]

vtc = VTC()
#########################################################################################


#########################################################################################
class Circuit:
    def __init__(self,fname):
        data = np.load(fname)
        self.data = data

        w0 = data['w0']
        b0 = data['b0']
        p0, n0 = np.maximum(0., w0), np.maximum(0., -w0)
        bmax = VDD - np.sum(np.abs(w0), axis=0)

        ypb1 = b0 - np.sum(np.abs(n0), axis=0)
        ypb = np.where(np.where(ypb1 > bmax, bmax, ypb1) < 0, 0, ypb1)

        ynb1 = VDD - b0 - np.sum(np.abs(p0), axis=0)
        ynb = np.where(np.where(ynb1 > bmax, bmax, ynb1) < 0, 0, ynb1)

        p0, n0 = p0/alpha_0, n0/alpha_0

        G0SA = p0 * C0
        G0SB = n0 * C0
        G0BAP = ypb * C0 / VDD
        G0BBP = C0 - np.sum(G0SA,0) - np.sum(G0SB,0) - G0BAP
        G0BBN = ynb * C0 / VDD
        G0BAN = C0 - np.sum(G0SA,0) - np.sum(G0SB,0) - G0BBN


        self.G0SA = G0SA
        self.G0SB = G0SB
        self.G0BAP = G0BAP
        self.G0BBP = G0BBP
        self.G0BBN = G0BBN
        self.G0BAN = G0BAN

        self.BIAS0 = VDD


        w1 = data['wf']
        b1 = data['bf']
        self.b1 = b1
        self.w1 = w1


    def encode(self,x):
        #x = np.reshape(x,[-1,1])

        G0SA = self.G0SA; G0SB = self.G0SB; G0BAP = self.G0BAP; G0BBP = self.G0BBP; G0BAN = self.G0BAN; G0BBN = self.G0BBN;BIAS0 = self.BIAS0
        w1 = self.w1; b1 = self.b1

        p0, n0 = G0SA /(np.sum(G0SA,0) + np.sum(G0SB,0) + G0BAP + G0BBP), G0SB /(np.sum(G0SA,0) + np.sum(G0SB,0) + G0BAN + G0BBN)
        ypb,ynb = BIAS0 * G0BAP/(np.sum(G0SA,0) + np.sum(G0SB,0) + G0BAP + G0BBP), BIAS0 * G0BBN/(np.sum(G0SA,0) + np.sum(G0SB,0) + G0BAN + G0BBN)

        yp = np.matmul(x, p0) + np.matmul((VDD - x), n0) + ypb
        yn = np.matmul((VDD - x), p0) + np.matmul(x, n0) + ynb



        yp = vtc.act(yp - OFFS) - VCM
        yn = vtc.act(yn - OFFS) - VCM

        pf, nf = np.maximum(0., w1), np.maximum(0., -w1)
        y = np.matmul(yp, pf) + np.matmul(yn, nf) + b1

        #return np.float32(y > VM_1)
        return y

#################################################


import sys

nBits1 = 3
nBits2 = 7


ckt = Circuit(sys.argv[1])
# tm = np.linspace(0.,2*np.pi,2**15)
sig = np.linspace(0., 1-1e-4, 2 ** 15)

tm = np.int64(np.round((sig - (2 ** (-nBits1 - 1))) * 2 ** nBits1))
code = makeCode(nBits1,nBits2)
smooth_in = VDD * code[tm.flatten(), :]
signal = np.column_stack((VDD * sig, smooth_in))

quant = ckt.encode(signal)



if len(sys.argv) == 3:
    import matplotlib as mp

    mp.use('Agg')
    import matplotlib.pyplot as plt

    # plt.plot(tm,gt,'-g',linewidth=1.5)
    plt.plot(sig, quant, '-r', linewidth=1.5)

    plt.ylim([-1.5, 1.5])
    #    plt.title("%d Bits, %d Hidden Neurons: ENOB = %.2f" % (ckt.nBits,ckt.nHidden,ENOB))
    plt.savefig(sys.argv[2], dpi=120)
