#-- Ayan Chakrabarti <ayan@wustl.edu>

import numpy as np
import tensorflow as tf
import csvact as ca

_vtc = ca.VTC()
#VDD=3.0#3.0
VDD=1.4#3.0

VCMi = 0.4729492
VCM = 0.6
OFFS = 0.5 * VDD - VCMi

# Activation of hidden layer
def activ1(x):
    #return tf.sigmoid(x)
    return _vtc.act(x)

# "Hard" / non-differentiable activation of final layer
#def activ2(x):
    #return tf.cast(x > 0,tf.float32)

# Differentiable activation+loss wrt true value being positive or negative
def activ2L(x):
    return [tf.nn.softplus(-x), tf.nn.softplus(x)]


class Circuit:
    def __init__(self,nHidden=4,nBits=8):
        self.wts = {}
        w0 = np.float32(np.random.uniform(-1, 1, [8, nHidden]))/4.0
        self.wts['w0'] = tf.Variable(tf.constant(w0, shape=[8, nHidden]),dtype=tf.float32)
        b0 = 0.5*(VDD - np.sum(np.abs(w0)/8, axis=0))
        self.wts['b0'] = tf.Variable(tf.constant(b0, shape=[nHidden]), dtype=tf.float32)
        
        #wf = np.float32(np.random.uniform(-np.sqrt(3.0/nHidden), np.sqrt(3.0/nHidden), [nHidden,nBits]))/VCM/2
        #self.wts['wf'] = tf.Variable(tf.constant(wf,shape=[nHidden, nBits]),dtype=tf.float32)
        #self.wts['bf'] = tf.Variable(tf.zeros(shape=[nBits]), dtype=tf.float32)

        wf = np.float32(np.random.uniform(-np.sqrt(3.0/nHidden), np.sqrt(3.0/nHidden), [nHidden,1]))/VCM/2
        self.wts['wf'] = tf.Variable(tf.constant(wf,shape=[nHidden, 1]),dtype=tf.float32)
        self.wts['bf'] = tf.Variable(tf.zeros(shape=[1]), dtype=tf.float32)



        # Ops to clip first layer
        v = tf.clip_by_value(self.wts['w0'],-0.0625*VDD,0.0625*VDD)
        v1 = tf.abs(v) / tf.maximum(1e-8,tf.abs(self.wts['w0']))
        #v1 = (self.wts['b0'] - 0.5*VDD)*tf.reshape(v1,[-1]) + 0.5*VDD
        #v1 = (self.wts['b0'] - 0.5*VDD)*tf.reshape(tf.reduce_sum(tf.abs(v1), axis=0), [-1]) + 0.5*VDD
        v1 = (self.wts['b0'] - 0.5 * VDD) * tf.reduce_sum(tf.abs(v1), axis=0)/8 + 0.5 * VDD

        with tf.control_dependencies([v,v1]):
            self.cOp = [tf.assign(self.wts['w0'],v),tf.assign(self.wts['b0'],v1)]

    def encode(self,x):
        w0 = self.wts['w0'] #self.w0
        p0, n0 = tf.maximum(0., w0), tf.maximum(0., -w0)
        #bmax = tf.stop_gradient(VDD-tf.abs(tf.squeeze(w0, axis=[0])))
        bmax = tf.stop_gradient(VDD-tf.reduce_sum(tf.abs(w0), axis=0))

        #added by weidong
        #self.sq = tf.squeeze(w0,axis=[0])
        #self.n0 = n0
        #end

        ypb = self.wts['b0'] - tf.reduce_sum(tf.abs(n0), axis=0)
        #self.sn0 = tf.stop_gradient(tf.squeeze(n0,[0]))
        ypb = tf.clip_by_value(ypb,0.,bmax)
        
        ynb = VDD-self.wts['b0'] - tf.reduce_sum(tf.abs(p0), axis=0)
        ynb = tf.clip_by_value(ynb,0.,bmax)

        yp = tf.matmul(x, p0) + tf.matmul((1-x), n0) + ypb
        yn = tf.matmul((1-x), p0) + tf.matmul(x, n0) + ynb

        #yp = activ1(yp-OFFS)-VCM
        #yn = activ1(yn-OFFS)-VCM


        yp = activ1(yp)
        yn = activ1(yn)

        wf = self.wts['wf']
        pf,nf = tf.maximum(0.,wf),tf.maximum(0.,-wf)
        y = tf.matmul(yp,pf) + tf.matmul(yn,nf) + self.wts['bf']

        return y
