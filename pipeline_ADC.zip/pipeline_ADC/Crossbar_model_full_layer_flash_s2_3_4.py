# weidong.cao@wustl.edu

# Inverter size: PMOS:W=4000nm; NMOS:W=11000nm.Minimum length.
# The model only from the first layer crossbar output to final output.The second layer is single path. s6_8_12

import re
import os
from glob import glob
import numpy as np
import sys

VDD_H = 2
C0 = 0.0001
C1 = 0.00001
#C1 = 0.00001
alpha_0 = VDD_H / 1
VCMi = 0.533225
VCM = 0.75
OFFS = 0.5 * VDD_H - VCMi

VMAX = 1.501225
VMIN = 0.001225

VH_0 = OFFS + VMAX
VL_0 = OFFS + VMIN

reso = 3

class ReRAM_extractor:

    def __init__(self,fname):

        data = np.load(fname)
        self.data = data

        w0 = data['w0']
        b0 = data['b0']
        p0, n0 = np.maximum(0., w0), np.maximum(0., -w0)

        p0 = np.round(p0/(0.20*VDD_H) * (2**reso-1)) / ((2**reso-1)) * (0.20*VDD_H)
        n0 = np.round(n0/(0.20*VDD_H) * (2**reso-1)) / ((2**reso-1)) * (0.20*VDD_H)

        bmax = VDD_H - np.sum(np.abs(w0), axis=0)
        ypb1 = b0 - np.sum(np.abs(n0), axis=0)
        ypb = np.where(np.where(ypb1 > bmax, bmax, ypb1) < 0, 0, ypb1)

        ynb1 = VDD_H - b0 - np.sum(np.abs(p0), axis=0)
        ynb = np.where(np.where(ynb1 > bmax, bmax, ynb1) < 0, 0, ynb1)

        p0, n0 = p0 / alpha_0, n0 / alpha_0


        G0SA = p0 * C0
        G0SB = n0 * C0
        G0BAP = ypb * C0 / VDD_H
        b = G0BAP[1]
        G0BBP = C0 - G0SA - G0SB - G0BAP
        G0BBN = ynb * C0 / VDD_H
        G0BAN = C0 - G0SA - G0SB - G0BBN

        self.G0SA = G0SA
        self.G0SB = G0SB
        self.G0BAP = G0BAP
        self.G0BBP = G0BBP
        self.G0BBN = G0BBN
        self.G0BAN = G0BAN

        self.BIAS0 = VDD_H

        w1 = data['wf']
        b1 = data['bf']
        div = np.sum(np.abs(w1), 0)
        w1 = w1 / (1.5 * div)
        b1 = b1 / (1.5 * div)




        pf, nf = np.maximum(0., w1), np.maximum(0., -w1)
        pf = np.round(pf / (np.maximum(np.max(pf), np.max(nf))) * (2 ** reso - 1)) / ((2 ** reso - 1)) * np.maximum(
            np.max(pf), np.max(nf))
        nf = np.round(nf / (np.maximum(np.max(pf), np.max(nf))) * (2 ** reso - 1)) / ((2 ** reso - 1)) * np.maximum(
            np.max(pf), np.max(nf))


        G1SA = pf * C0
        G1SB = nf * C0
        VM_1 = VDD_H / 2
        BIAS1 = VDD_H

        b1crossbar = np.matmul((-VCM - OFFS) * np.ones(b0.shape[0]), (pf + nf)) + b1 + VM_1
        G1BA = b1crossbar * C0 / BIAS1
        G1BB = C0 - np.sum(G1SA, 0) - np.sum(G1SB, 0) - G1BA

        self.nBits = b1.shape[0]
        self.nHidden = b0.shape[0]

        self.G1SA = G1SA
        self.G1SB = G1SB
        self.G1BA = G1BA
        self.G1BB = G1BB
        self.BIAS1 = BIAS1


    def write_res0s(self,rdex,index,oudex,iter,r,c):

        fileObject.write(' ')
        fileObject.write(' ')
        fileObject.write(' ')
        fileObject.write(' ')
        fileObject.write('R')
        fileObject.write(rdex)  # index of resis
        fileObject.write(str(iter))
        fileObject.write(' ')
        fileObject.write('(')
        fileObject.write(index)  # index of input port of resis
        #fileObject.write(str(iter))
        fileObject.write(' ')
        fileObject.write(oudex)  # index of output port of resis
        fileObject.write('\\')
        fileObject.write('<')
        fileObject.write(str(iter))
        fileObject.write('\\')
        fileObject.write('>')

        fileObject.write(')')
        fileObject.write(' ')
        fileObject.write('resistor')
        fileObject.write(' ')
        fileObject.write('r=')
        fileObject.write(str(r))
        fileObject.write(' ')
        fileObject.write('c=')
        fileObject.write(str(c))
        fileObject.write('\n')

    def write_res0b(self,rdex,index,oudex,iter,r,c):

        fileObject.write(' ')
        fileObject.write(' ')
        fileObject.write(' ')
        fileObject.write(' ')
        fileObject.write('R')
        fileObject.write(rdex)  # index of resis
        fileObject.write(str(iter))
        fileObject.write(' ')

        fileObject.write('(')
        fileObject.write(index)  # index of input port of resis
        fileObject.write('\\')
        fileObject.write('<')
        fileObject.write(str(iter))
        fileObject.write('\\')
        fileObject.write('>')

        fileObject.write(' ')
        fileObject.write(oudex)  # index of output port of resis
        fileObject.write('\\')
        fileObject.write('<')
        fileObject.write(str(iter))
        fileObject.write('\\')
        fileObject.write('>')

        fileObject.write(')')
        fileObject.write(' ')
        fileObject.write('resistor')
        fileObject.write(' ')
        fileObject.write('r=')
        fileObject.write(str(r))
        fileObject.write(' ')
        fileObject.write('c=')
        fileObject.write(str(c))
        fileObject.write('\n')

    def write_inv0_NMOS(self,type,invdex,outdex,vindex,grounddex,subdex,iter):

        fileObject.write(' ')
        fileObject.write(' ')
        fileObject.write(' ')
        fileObject.write(' ')
        fileObject.write('T')
        fileObject.write(invdex)  # index of resis
        fileObject.write(str(iter))
        fileObject.write(' ')
        fileObject.write('(')
        fileObject.write(outdex)  # index of output port of resis

        fileObject.write('\\')
        fileObject.write('<')
        fileObject.write(str(iter))
        fileObject.write('\\')
        fileObject.write('>')

        fileObject.write(' ')
        fileObject.write(vindex) # index of input port of resis
        fileObject.write('\\')
        fileObject.write('<')
        fileObject.write(str(iter))
        fileObject.write('\\')
        fileObject.write('>')

        fileObject.write(' ')
        fileObject.write(grounddex)
        fileObject.write(' ')
        fileObject.write(subdex)
        fileObject.write(')')
        fileObject.write(' ')
        fileObject.write(type)
        fileObject.write(' ')
        fileObject.write('l=120.0n w=11.0u nf=1 m=1 par=1 ngcon=1')
        fileObject.write(' ')
        fileObject.write('\\')
        fileObject.write('\n')
        fileObject.write('\t')
        fileObject.write('ad=6.05e-12 as=6.05e-12 pd=23.1u ps=23.1u nrd=0.0164 nrs=0.0164')
        fileObject.write(' ')
        fileObject.write('\\')
        fileObject.write('\n')
        fileObject.write('\t')
        fileObject.write('rf_rsub=1 plnest=-1 plorient=-1 pld200=-1 pwd100=-1 lstis=1 lnws=0')
        fileObject.write(' ')
        fileObject.write('\\')
        fileObject.write('\n')
        fileObject.write('\t')
        fileObject.write('rgatemod=0 rbodymod=0 panw1=0p panw2=0p panw3=0p panw4=0p panw5=0p')
        fileObject.write(' ')
        fileObject.write('\\')
        fileObject.write('\n')
        fileObject.write('\t')
        fileObject.write('panw6=0p panw7=0p panw8=0p panw9=0p panw10=0p sa=5.5e-07')
        fileObject.write(' ')
        fileObject.write('\\')
        fileObject.write('\n')
        fileObject.write('\t')
        fileObject.write('sb=5.5e-07 sd=0u dtemp=0')
        fileObject.write('\n')

    def write_inv0_PMOS(self,type,invdex,outdex,vindex,grounddex,subdex,iter):

        fileObject.write(' ')
        fileObject.write(' ')
        fileObject.write(' ')
        fileObject.write(' ')
        fileObject.write('T')
        fileObject.write(invdex)  # index of resis
        fileObject.write(str(iter))
        fileObject.write(' ')
        fileObject.write('(')
        fileObject.write(outdex)  # index of output port of resis

        fileObject.write('\\')
        fileObject.write('<')
        fileObject.write(str(iter))
        fileObject.write('\\')
        fileObject.write('>')

        fileObject.write(' ')
        fileObject.write(vindex) # index of input port of resis
        fileObject.write('\\')
        fileObject.write('<')
        fileObject.write(str(iter))
        fileObject.write('\\')
        fileObject.write('>')

        fileObject.write(' ')
        fileObject.write(grounddex)
        fileObject.write(' ')
        fileObject.write(subdex)
        fileObject.write(')')
        fileObject.write(' ')
        fileObject.write(type)
        fileObject.write(' ')
        fileObject.write('l=120.0n w=4u nf=1 m=1 par=1 ngcon=1 ad=2.2e-12')
        fileObject.write(' ')
        fileObject.write('\\')
        fileObject.write('\n')
        fileObject.write('\t')
        fileObject.write('as=2.2e-12 pd=9.1u ps=9.1u nrd=0.045 nrs=0.045 rf_rsub=1')
        fileObject.write(' ')
        fileObject.write('\\')
        fileObject.write('\n')
        fileObject.write('\t')
        fileObject.write('plnest=-1 plorient=-1 pld200=-1 pwd100=-1 lstis=1 lnws=0')
        fileObject.write(' ')
        fileObject.write('\\')
        fileObject.write('\n')
        fileObject.write('\t')
        fileObject.write('rgatemod=0 rbodymod=0 panw1=0p panw2=0p panw3=0p panw4=0p panw5=0p')
        fileObject.write(' ')
        fileObject.write('\\')
        fileObject.write('\n')
        fileObject.write('\t')
        fileObject.write('panw6=0p panw7=0p panw8=0p panw9=0p panw10=0p sa=5.5e-07')
        fileObject.write(' ')
        fileObject.write('\\')
        fileObject.write('\n')
        fileObject.write('\t')
        fileObject.write('sb=5.5e-07 sd=0u dtemp=0')
        fileObject.write('\n')

    def write_res1s(self, redex, rdex, cdex, index, oudex, lr, lw, r, c):

        fileObject.write(' ')
        fileObject.write(' ')
        fileObject.write(' ')
        fileObject.write(' ')
        fileObject.write('R')
        fileObject.write(redex)  # index of resis
        fileObject.write(rdex)  # row index of resis
        fileObject.write(str(lr))
        fileObject.write(cdex)  # column index of resis
        fileObject.write(str(lw))  # index of input port of resis
        fileObject.write(' ')

        fileObject.write('(')
        fileObject.write(index)  # index of input port of resis
        fileObject.write('\\')
        fileObject.write('<')
        fileObject.write(str(lr))
        fileObject.write('\\')
        fileObject.write('>')

        fileObject.write(' ')
        fileObject.write(oudex)  # index of output port of resis
        fileObject.write('\\')
        fileObject.write('<')
        fileObject.write(str(lw))
        fileObject.write('\\')
        fileObject.write('>')
        fileObject.write(')')

        fileObject.write(' ')
        fileObject.write('resistor')
        fileObject.write(' ')
        fileObject.write('r=')
        fileObject.write(str(r))
        fileObject.write(' ')
        fileObject.write('c=')
        fileObject.write(str(c))
        fileObject.write('\n')

    def write_res1b(self, redex, rdex, cdex, index, oudex, lr, lw, r, c):

        fileObject.write(' ')
        fileObject.write(' ')
        fileObject.write(' ')
        fileObject.write(' ')
        fileObject.write('R')
        fileObject.write(redex)  # index of resis
        fileObject.write(rdex)  # row index of resis
        fileObject.write(str(lr))
        fileObject.write(cdex)  # column index of resis
        fileObject.write(str(lw))  # index of input port of resis
        fileObject.write(' ')
        fileObject.write('(')
        fileObject.write(index)  # index of input port of resis

        fileObject.write('\\')
        fileObject.write('<')
        fileObject.write(str(lw))
        fileObject.write('\\')
        fileObject.write('>')

        fileObject.write(' ')
        fileObject.write(oudex)  # index of output port of resis
        fileObject.write('\\')
        fileObject.write('<')
        fileObject.write(str(lw))
        fileObject.write('\\')
        fileObject.write('>')

        fileObject.write(')')
        fileObject.write(' ')
        fileObject.write('resistor')
        fileObject.write(' ')
        fileObject.write('r=')
        fileObject.write(str(r))
        fileObject.write(' ')
        fileObject.write('c=')
        fileObject.write(str(c))
        fileObject.write('\n')

    def write_inv1_NMOS(self, type, invdex, outdex, vindex, grounddex, subdex, iter):

        fileObject.write(' ')
        fileObject.write(' ')
        fileObject.write(' ')
        fileObject.write(' ')
        fileObject.write('T')
        fileObject.write(invdex)  # index of resis
        fileObject.write(str(iter))
        fileObject.write(' ')
        fileObject.write('(')
        fileObject.write(outdex)  # index of output port of resis
        fileObject.write('\\')
        fileObject.write('<')
        fileObject.write(str(iter))
        fileObject.write('\\')
        fileObject.write('>')
        fileObject.write(' ')
        fileObject.write(vindex)  # index of input port of resis
        fileObject.write('\\')
        fileObject.write('<')
        fileObject.write(str(iter))
        fileObject.write('\\')
        fileObject.write('>')

        fileObject.write(' ')
        fileObject.write(grounddex)
        fileObject.write(' ')
        fileObject.write(subdex)
        fileObject.write(')')
        fileObject.write(' ')
        fileObject.write(type)
        fileObject.write(' ')
        fileObject.write('l=120.0n w=11.0u nf=1 m=1 par=1 ngcon=1')
        fileObject.write(' ')
        fileObject.write('\\')
        fileObject.write('\n')
        fileObject.write('\t')
        fileObject.write('ad=6.05e-12 as=6.05e-12 pd=23.1u ps=23.1u nrd=0.0164 nrs=0.0164')
        fileObject.write(' ')
        fileObject.write('\\')
        fileObject.write('\n')
        fileObject.write('\t')
        fileObject.write('rf_rsub=1 plnest=-1 plorient=-1 pld200=-1 pwd100=-1 lstis=1 lnws=0')
        fileObject.write(' ')
        fileObject.write('\\')
        fileObject.write('\n')
        fileObject.write('\t')
        fileObject.write('rgatemod=0 rbodymod=0 panw1=0p panw2=0p panw3=0p panw4=0p panw5=0p')
        fileObject.write(' ')
        fileObject.write('\\')
        fileObject.write('\n')
        fileObject.write('\t')
        fileObject.write('panw6=0p panw7=0p panw8=0p panw9=0p panw10=0p sa=5.5e-07')
        fileObject.write(' ')
        fileObject.write('\\')
        fileObject.write('\n')
        fileObject.write('\t')
        fileObject.write('sb=5.5e-07 sd=0u dtemp=0')
        fileObject.write('\n')

    def write_inv1_PMOS(self, type, invdex, outdex, vindex, grounddex, subdex, iter):

        fileObject.write(' ')
        fileObject.write(' ')
        fileObject.write(' ')
        fileObject.write(' ')
        fileObject.write('T')
        fileObject.write(invdex)  # index of resis
        fileObject.write(str(iter))
        fileObject.write(' ')
        fileObject.write('(')
        fileObject.write(outdex)  # index of output port of resis
        fileObject.write('\\')
        fileObject.write('<')
        fileObject.write(str(iter))
        fileObject.write('\\')
        fileObject.write('>')
        fileObject.write(' ')
        fileObject.write(vindex)  # index of input port of resis
        fileObject.write('\\')
        fileObject.write('<')
        fileObject.write(str(iter))
        fileObject.write('\\')
        fileObject.write('>')

        fileObject.write(' ')
        fileObject.write(grounddex)
        fileObject.write(' ')
        fileObject.write(subdex)
        fileObject.write(')')
        fileObject.write(' ')
        fileObject.write(type)
        fileObject.write(' ')
        fileObject.write('l=120.0n w=4u nf=1 m=1 par=1 ngcon=1 ad=2.2e-12')
        fileObject.write(' ')
        fileObject.write('\\')
        fileObject.write('\n')
        fileObject.write('\t')
        fileObject.write('as=2.2e-12 pd=9.1u ps=9.1u nrd=0.045 nrs=0.045 rf_rsub=1')
        fileObject.write(' ')
        fileObject.write('\\')
        fileObject.write('\n')
        fileObject.write('\t')
        fileObject.write('plnest=-1 plorient=-1 pld200=-1 pwd100=-1 lstis=1 lnws=0')
        fileObject.write(' ')
        fileObject.write('\\')
        fileObject.write('\n')
        fileObject.write('\t')
        fileObject.write('rgatemod=0 rbodymod=0 panw1=0p panw2=0p panw3=0p panw4=0p panw5=0p')
        fileObject.write(' ')
        fileObject.write('\\')
        fileObject.write('\n')
        fileObject.write('\t')
        fileObject.write('panw6=0p panw7=0p panw8=0p panw9=0p panw10=0p sa=5.5e-07')
        fileObject.write(' ')
        fileObject.write('\\')
        fileObject.write('\n')
        fileObject.write('\t')
        fileObject.write('sb=5.5e-07 sd=0u dtemp=0')
        fileObject.write('\n')


ckt = ReRAM_extractor(sys.argv[1])

l0 = ckt.G0SA.shape[1]
l1 = ckt.G1SA.shape[0]
w1 = ckt.G1SA.shape[1]
c = 0

fileObject = open('../save_model/first_stage/f_s2_3_4_full_layer', 'w')

fileObject.write('//This is ReRAM crossbar netlist for the first layer')
fileObject.write('\n')

for i in range (l0):

    # This is to instantiate resistance for the first layer.

    # Positive side
    if ckt.G0SA[0, i] > 0:

        ckt.write_res0s('_subA_0_S_P', 'IN_A_0_S', 'OUT_0_P', i, 1/ckt.G0SA[0, i], c) # ReRAM in first layer of A sub-crossbar array, signal side;

    if ckt.G0SB[0, i] > 0:

        ckt.write_res0s('_subB_0_S_P', 'IN_B_0_S', 'OUT_0_P', i, 1/ckt.G0SB[0, i], c) # ReRAM in first layer of B sub-crossbar array, signal side;

    if ckt.G0BAP[i] > 0:

        ckt.write_res0b('_subA_0_B_P', 'IN_A_0_Bias', 'OUT_0_P', i, 1/ckt.G0BAP[i], c) # ReRAM in first layer of A sub-crossbar array, bias side;

    if ckt.G0BBP[0, i] > 0:

        ckt.write_res0b('_subB_0_B_P', 'IN_B_0_Bias', 'OUT_0_P', i, 1/ckt.G0BBP[0, i], c) # ReRAM in first layer of B sub-crossbar array, bias side;
    #end


    ckt.write_inv0_NMOS('nfet', '_0_P_N', '_subA_1_S_P', 'OUT_0_P', 'VL_0', 'VL_0', i)
    ckt.write_inv0_PMOS('pfet', '_0_P_P', '_subA_1_S_P', 'OUT_0_P', 'VH_0', 'VH_0', i)


    # Negative side
    if ckt.G0SA[0, i] > 0:

        ckt.write_res0s('_subA_0_S_N', 'IN_B_0_S', 'OUT_0_N', i, 1/ckt.G0SA[0, i], c) # ReRAM in first layer of A sub-crossbar array, signal side;

    if ckt.G0SB[0, i] > 0:

        ckt.write_res0s('_subB_0_S_N', 'IN_A_0_S', 'OUT_0_N', i, 1/ckt.G0SB[0, i], c) # ReRAM in first layer of B sub-crossbar array, signal side;

    if ckt.G0BAN[0, i] > 0:

        ckt.write_res0b('_subA_0_B_N', 'IN_B_0_Bias', 'OUT_0_N', i, 1/ckt.G0BAN[0, i], c) # ReRAM in first layer of A sub-crossbar array, bias side;

    if ckt.G0BBN[i] > 0:

        ckt.write_res0b('_subB_0_B_N', 'IN_A_0_Bias', 'OUT_0_N', i, 1/ckt.G0BBN[i], c) # ReRAM in first layer of B sub-crossbar array, bias side;
    #end

    ckt.write_inv0_NMOS('nfet', '_0_N_N', '_subA_1_S_N', 'OUT_0_N', 'VL_0', 'VL_0', i)
    ckt.write_inv0_PMOS('pfet', '_0_N_P', '_subA_1_S_N', 'OUT_0_N', 'VH_0', 'VH_0', i)



fileObject.write('\n')
fileObject.write('\n')
fileObject.write('\n')
fileObject.write('\n')
fileObject.write('\n')
fileObject.write('\n')


fileObject.write('//This is ReRAM crossbar netlist for the second layer')
fileObject.write('\n')


for i in range (w1):
    for j in range (l1):


        #fileObject.write('//This is ReRAM crossbar for the second layer on positive side')

        # Positive side
        if ckt.G1SA[j, i] > 0:

            ckt.write_res1s('_subA_1_S_P', '_r_', '_c_', '_subA_1_S_P', 'OUT_1_P', j, i, 1/ckt.G1SA[j, i], c)  # ReRAM in first layer of A sub-crossbar array, signal side;

        if ckt.G1SB[j, i] > 0:

            ckt.write_res1s('_subB_1_S_P', '_r_', '_c_', '_subA_1_S_N', 'OUT_1_P', j, i, 1/ckt.G1SB[j, i], c)  # ReRAM in first layer of B sub-crossbar array, signal side;
        # end


    ckt.write_res1b('_subA_1_B_P', '_r_', '_c_', 'IN_A_1_Bias', 'OUT_1_P', j+1, i, 1/ckt.G1BA[i], c)  # ReRAM in first layer of A sub-crossbar array, bias side;
    ckt.write_res1b('_subB_1_B_P', '_r_', '_c_', 'IN_B_1_Bias', 'OUT_1_P', j+1, i, 1/ckt.G1BB[i], c)  # ReRAM in first layer of B sub-crossbar array, bias side;

    ckt.write_inv1_NMOS('nfet', '_1_P_N', '_subA_2_S_P', 'OUT_1_P', 'VL_1', 'VL_1', i)
    ckt.write_inv1_PMOS('pfet', '_1_P_P', '_subA_2_S_P', 'OUT_1_P', 'VH_1', 'VH_1', i)

fileObject.close()
