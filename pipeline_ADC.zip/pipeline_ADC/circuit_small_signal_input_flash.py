#-- Ayan Chakrabarti <ayan@wustl.edu>

import numpy as np
import tensorflow as tf
import csvact as ca

_vtc = ca.VTC()
#VCMi = 0.551553
VCMi = 0.533225

VCM = 0.75
#VDD= 2*VCMi
VDD_H = 2
OFFS = 0.5 * VDD_H - VCMi

# Activation of hidden layer
def activ1(x):
    #return tf.sigmoid(x)
    return _vtc.act(x)

# "Hard" / non-differentiable activation of final layer
def activ2(x):
    return tf.cast(x > 0,tf.float32)

# Differentiable activation+loss wrt true value being positive or negative
def activ2L(x):
    return [tf.nn.softplus(-x), tf.nn.softplus(x)]


class Circuit:
    def __init__(self,nHidden=4,nBits=8):
        self.wts = {}
        w0 = np.float32(np.random.uniform(-1, 1, [1, nHidden])) / 4.0
        self.wts['w0'] = tf.Variable(tf.constant(w0, shape=[1, nHidden]),dtype=tf.float32)
        b0 = 0.5 * (VDD_H - w0)
        self.wts['b0'] = tf.Variable(tf.constant(b0, shape=[nHidden]), dtype=tf.float32)


        wf = np.float32(np.random.uniform(-np.sqrt(3.0/nHidden), np.sqrt(3.0/nHidden), [nHidden,nBits]))/VCM/2
        self.wts['wf'] = tf.Variable(tf.constant(wf,shape=[nHidden, nBits]),dtype=tf.float32)
        self.wts['bf'] = tf.Variable(tf.zeros(shape=[nBits]), dtype=tf.float32)



        # Ops to clip first layer
        v = tf.clip_by_value(self.wts['w0'],-0.20*VDD_H,0.20*VDD_H)

        #v = tf.round(v / (0.25 * VDD_H) * (2 ** 3 - 1)) / (2 ** 3 - 1)
        v1 = tf.abs(v) / tf.maximum(1e-8,tf.abs(self.wts['w0']))

        #v2 = tf.round(self.wts['wf'] / (tf.reduce_max(tf.abs(self.wts['wf']))) * (2 ** 3 - 1)) / ((2 ** 3 - 1))

        v1 = (self.wts['b0'] - 0.5*VDD_H)*tf.reshape(v1,[-1]) + 0.5*VDD_H
        with tf.control_dependencies([v,v1]):
            self.cOp = [tf.assign(self.wts['w0'], v), tf.assign(self.wts['b0'], v1)]
            #self.cOw = [tf.assign(self.wts['wf'], v2)]

    def encode(self,x):
        w0 = self.wts['w0'] #self.w0
        p0, n0 = tf.maximum(0., w0), tf.maximum(0., -w0)

        #p0 = tf.round(p0/(0.25*VDD_H) * (2**3-1)) / ((2**3-1))
        #n0 = tf.round(n0/(0.25*VDD_H) * (2**3-1)) / ((2**3-1))

        bmax = tf.stop_gradient(VDD_H-tf.reduce_sum(tf.abs(w0), axis=0))

        # h_t_n = tf.round(h_t_n_1*1e5)/(1e5)

        ypb = self.wts['b0'] - tf.reduce_sum(tf.abs(n0), axis=0)
        ypb = tf.clip_by_value(ypb,0.,bmax)
        
        ynb = VDD_H-self.wts['b0'] - tf.reduce_sum(tf.abs(p0), axis=0)
        ynb = tf.clip_by_value(ynb,0.,bmax)

        ### First stage
        #yp = tf.matmul(x, p0) + tf.matmul((1-x), n0) + ypb
        #yn = tf.matmul((1-x), p0) + tf.matmul(x, n0) + ynb

        ### Second stage
        yp = tf.matmul(x, p0) + tf.matmul((VDD_H-x), n0) + ypb
        yn = tf.matmul((VDD_H-x), p0) + tf.matmul(x, n0) + ynb

        yp = activ1(yp-OFFS)-VCM
        yn = activ1(yn-OFFS)-VCM

        wf = self.wts['wf']
        bf = self.wts['bf']

        pf,nf = tf.maximum(0.,wf),tf.maximum(0.,-wf)

        #pf = tf.round(pf/(tf.maximum(tf.reduce_max(pf), tf.reduce_max(nf))) * (2**3-1)) / ((2**3-1))
        #nf = tf.round(nf/(tf.maximum(tf.reduce_max(pf), tf.reduce_max(nf))) * (2**3-1)) / ((2**3-1))


        y = tf.matmul(yp,pf) + tf.matmul(yn,nf) + bf

        return [activ2(y), activ2L(y)]
