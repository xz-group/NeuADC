import numpy as np

sig = np.linspace(0,0.8,9)[:-1]
out_d = sig.copy()
print ('sig', sig)
index1 = np.where(sig >= 0.5)
index2 = np.where(sig < 0.5)
sig[index1] = 2*(sig[index1] - 0.5)
sig[index2] = 2*sig[index2]
ovec = sig

#out_d = sig
out_d[index1] = 0.5
out_d[index2] = 0


print ('sig', sig)
print ('ovec', ovec)
print ('out_d', out_d)
#print ('sig', sig[sig>=0.5])
#sig[sig>=0.5]=2*(sig[sig>=0.5]-0.5)
#print ('sig', sig)