#-- Ayan Chakrabarti <ayan@wustl.edu>


import numpy as np
import tensorflow as tf
#import math


# tensorflow version compatibility
def _unpack(x,num=None):
    try:
        return tf.unstack(x,num)
    except:
        return tf.unpack(x,num)

####Binary to smooth codes

def makeCode(nb1, nb2):
    levels = 2 ** nb1
    lchg = np.zeros(nb2)

    def tostr(b):
        return ' '.join([str(int(i)) for i in b])

    codes = [np.zeros(nb2)]
    strs = [tostr(codes[0])]

    for id in range(1, levels):
        idx = np.argsort(lchg)
        for k in range(len(idx)):
            nb = codes[-1].copy()
            nb[idx[k]] = 1 - nb[idx[k]]
            st = tostr(nb)
            if st not in strs:
                lchg[idx[k]] = id
                codes.append(nb)
                strs.append(st)
                break
        assert len(strs) == id + 1

    return np.stack(codes, 0)

class Target:
    def __init__(self,imin=0,imax=1,omin=0.0,omax=1,nBits1=8,nBits2=10):

        self.imin = imin
        self.imax = imax
        self.omin = omin
        self.omax = omax
        self.nBits1 = nBits1
        self.nBits2 = nBits2
        self.code = makeCode(self.nBits1,self.nBits2)

    def rSamp(self,bsz=64,cg=16):
        dl = np.random.uniform(-4.,4.,size=[cg,bsz//cg])*2.0**(-self.nBits1)

        sig1 = np.float32(self.imin + np.random.sample([1, bsz//cg])*(self.imax-self.imin))
        sig1 = np.maximum(self.imin,np.minimum(self.imax,np.reshape(sig1 + dl, [bsz, 1])))
        sig, ovec = self.s2o(sig1) #initial one

        return sig, ovec

    def uSamp(self,bsz=8192):

        sig1 = np.linspace(self.imin,self.imax,bsz+1)[:-1]
        sig1 = np.float32(np.reshape(sig1, [bsz, 1]))
        sig, ovec = self.s2o(sig1)

        return sig,ovec

    def s2o(self, sig1):

        ###Here, we need to transfer binary code into smooth code, to be done.
        out = np.maximum(0.,sig1-self.omin)
        out = np.minimum(1-1e-4,out/(self.omax-self.omin))


        #out = np.int64(np.round((out/1 - (2 ** (-self.nBits1-1))) * 2 ** self.nBits1))
        out = np.int64(np.round((out/1 - (2 ** (-self.nBits1-1))) * 2 ** self.nBits1))


        ovec = ((2 ** self.nBits1 * sig1- 1*out)-0.5)*1




        #sig1 = 0.5 + (sig1 - 0.5) ### For the first stage training
        sig1 = 1 + 0.8 * sig1 - 0.4 ### For the second stage training

        #smooth_in = (self.code[out.flatten(),:]-0.5)*1+0.5 ### For the first stage training
        smooth_in = self.code[out.flatten(),:]*2 ### For the second stage training

        sig = np.column_stack((sig1, smooth_in))



        return sig, ovec

    # Computes encoded value, error, and loss nodes
    # Call with tensors / placeholders
    def Eval(self,gt,actl1=None):

        loss = None
        if actl1 is not None:
            loss = tf.reduce_sum((gt - actl1)**2, 1)  # sum of row vector
            #loss = tf.reduce_sum(gt*actl1[0]+(1-gt)*actl1[1],1)#sum of row vector
            loss = tf.reduce_mean(loss**2)#get mean for all dimensions

        return loss