#!/usr/bin/env python
# -- Ayan Chakrabarti <ayan@wustl.edu>

import numpy as np

# VDD=3
#VDD = 1.4

############## Inverter characteristics
#########################################################################################

#VCMi = 0.509911
VCMi = 0.550871
VCM = 0.8
#VDD = 2*VCMi
VDD_H = 2
OFFS = 0.5 * VDD_H - VCMi
FNAME = 'VTC_1_6.csv'
#FNAME = 's8_16h64_load_new_size5.csv'
#FNAME = 's6_8h12_load_new_size5.csv'
COL = 'M';
SKIP = 2;
#XMIN = 0.00295;
#XMAX = 1.20095;

XMIN = 0; XMAX = 1.6; XSTEP = 0.002




def makeCode(nb1, nb2):
    levels = 2 ** nb1
    lchg = np.zeros(nb2)

    def tostr(b):
        return ' '.join([str(int(i)) for i in b])

    codes = [np.zeros(nb2)]
    strs = [tostr(codes[0])]

    for id in range(1, levels):
        idx = np.argsort(lchg)
        for k in range(len(idx)):
            nb = codes[-1].copy()
            nb[idx[k]] = 1 - nb[idx[k]]
            st = tostr(nb)
            if st not in strs:
                lchg[idx[k]] = id
                codes.append(nb)
                strs.append(st)
                break
        assert len(strs) == id + 1

    return np.stack(codes, 0)



class VTC:
    def __init__(self):
        lines = open(FNAME).readlines()[SKIP:]
        data = [[float(x) if len(x) > 0 else 0.0 for x in l.split(',')] for l in lines]
        data = np.float32(data)

        self.GT = data[:, [0, ord(COL) - ord('A')]]

        data = data[:, ord(COL) - ord('A')]

        assert (data.shape[0] == int((XMAX - XMIN) / XSTEP) + 1)

        slope = (data[1:] - data[:-1]) / XSTEP
        offs = data[:-1] - slope * (XMIN + np.arange(slope.shape[0]) * XSTEP)

        self.slope = slope
        self.offs = offs
        self.midx = slope.shape[0] - 1

    def act(self, x):
        x = np.minimum(XMAX, np.maximum(XMIN, x))
        idx = np.floor((x - XMIN) / XSTEP)
        idx = np.int64(np.minimum(self.midx, np.maximum(0., idx)))

        return self.slope[idx] * x + self.offs[idx]


vtc = VTC()


#########################################################################################


#########################################################################################
class Circuit:
    def __init__(self, fname):
        data = np.load(fname)
        self.data = data

        w0 = data['w0']
        self.w0 = w0
        self.b0 = data['b0']

        w1 = data['wf']
        #div = np.sum(np.abs(w1), 0)
        #div = 0.8*np.sum(np.abs(w1), 0)
        #self.w1 = w1 / (1.2*div)
        self.w1 = w1

        b1 = data['bf']
        #self.b1 = b1 / (div)
        self.b1 = b1

        self.nBits = self.b1.shape[0]
        self.nHidden = self.b0.shape[0]

    def encode(self, x):
        #x = np.reshape(x, [-1, 1])
        w0 = self.w0; b0 = self.b0; w1 = self.w1; b1 = self.b1

        p0, n0 = np.maximum(0., w0), np.maximum(0., -w0)
        bmax = VDD_H - np.sum(np.abs(w0), axis=0)

        ypb1 = b0 - np.sum(np.abs(n0), axis=0)
        ypb = np.where(np.where(ypb1 > bmax, bmax, ypb1) < 0, 0, ypb1)

        ynb1 = VDD_H - b0 - np.sum(np.abs(p0), axis=0)
        ynb = np.where(np.where(ynb1 > bmax, bmax, ynb1) < 0, 0, ynb1)

        yp = np.matmul(x, p0) + np.matmul((1 - x), n0) + ypb ### For the first stage training
        yn = np.matmul((1 - x), p0) + np.matmul(x, n0) + ynb ### For the first stage training

        #yp = np.matmul(x, p0) + np.matmul((VDD_H - x), n0) + ypb ### For the second stage training
        #yn = np.matmul((VDD_H - x), p0) + np.matmul(x, n0) + ynb ### For the second stage training

        yp = vtc.act(yp - OFFS) - VCM
        yn = vtc.act(yn - OFFS) - VCM
        #yp = vtc.act(yp)
        #yn = vtc.act(yn)

        #pf, nf = np.maximum(0., w1), np.maximum(0., -w1)
        #bfmax = VDD_H - np.sum(np.abs(w1), axis=0)

        #ypbf = np.where(np.where(b1 > bfmax, bfmax, b1) < 0, 0, b1)




        #y = np.matmul(yp,pf) + np.matmul(yn,nf) + ypbf


        pf, nf = 1.0*np.maximum(0., w1), 1.0*np.maximum(0., -w1)
        y = np.matmul(yp, pf) + np.matmul(yn, nf) + b1
        return y


#################################################


import sys

nBits1 = 3
nBits2 = 4

ckt = Circuit(sys.argv[1])

# tm = np.linspace(0.,2*np.pi,2**15)
#sig = np.linspace(0., 0.8-1e-4, 2 ** 15)

sig = np.linspace(0., 1-1e-4, 2 ** 15) ### For the first stage training
sig1 = (sig-0.5) + 0.5 ### For the first stage training

#sig = np.linspace(0., 1-1e-4, 2 ** 15) ### For the second stage training
#sig1 = (sig-0.5) + 1 ### For the second stage training


tm = np.int64(np.round((sig/1 - (2 ** (-nBits1 - 1))) * 2 ** nBits1))
code = makeCode(nBits1,nBits2)

smooth_in = (code[tm.flatten(), :]-0.5)*1+0.5 ### For the first stage training
#smooth_in = (code[tm.flatten(), :]-0.5)*1+1 ### For the second stage training


signal = np.column_stack((sig1, smooth_in))
#signal = sig1
quant = ckt.encode(signal)
a = np.max(quant)
b = np.min(quant)

if len(sys.argv) == 3:
    import matplotlib as mp

    mp.use('Agg')
    import matplotlib.pyplot as plt

    # plt.plot(tm,gt,'-g',linewidth=1.5)
    plt.plot(sig1, quant, '-r', linewidth=1.5)

    plt.ylim([-0.6, 0.6])
    #    plt.title("%d Bits, %d Hidden Neurons: ENOB = %.2f" % (ckt.nBits,ckt.nHidden,ENOB))
    plt.savefig(sys.argv[2], dpi=120)
