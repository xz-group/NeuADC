#-- Ayan Chakrabarti <ayan@wustl.edu>

import numpy as np
import tensorflow as tf
import csvact as ca

_vtc = ca.VTC()
#VDD=3.0#3.0
VDD=1.5#3.0

VCMi = 0.4729492
VCM = 0.6
OFFS = 0.5 * VDD - VCMi

# Activation of hidden layer
def activ1(x):
    #return tf.sigmoid(x)
    return _vtc.act(x)

# "Hard" / non-differentiable activation of final layer
def activ2(x):
    return tf.cast(x > 0,tf.float32)

# Differentiable activation+loss wrt true value being positive or negative
def activ2L(x):
    return [tf.nn.softplus(-x), tf.nn.softplus(x)]


class Circuit:
    def __init__(self,nHidden=4,nBits=8):
        self.wts = {}
        w0 = np.float32(np.random.uniform(-1, 1, [1, nHidden])) / 2
        self.wts['w0'] = tf.Variable(tf.constant(w0, shape=[1, nHidden]),dtype=tf.float32)
        b0 = 0.5 * (VDD - w0)
        self.wts['b0'] = tf.Variable(tf.constant(b0, shape=[nHidden]), dtype=tf.float32)



        wf = np.float32(np.random.uniform(-np.sqrt(3.0/nHidden),np.sqrt(3.0/nHidden),[nHidden,nBits]))/VCM/2
        self.wts['wf'] = tf.Variable(tf.constant(wf,shape=[nHidden,nBits]),dtype=tf.float32)
        self.wts['bf'] = tf.Variable(tf.zeros(shape=[nBits]),dtype=tf.float32)





        # Ops to clip first layer
        v = tf.clip_by_value(self.wts['w0'], -0.4 * VDD, 0.4 * VDD)
        v = tf.round(v / (0.4 * VDD) * (2 ** 1 - 1)) / (2 ** 1 - 1)
        v1 = tf.abs(v) / tf.maximum(1e-8,tf.abs(self.wts['w0']))
        v1 = (self.wts['b0'] - 0.5 * VDD) * tf.reshape(v1,[-1]) + 0.5 * VDD

        # Ops to clip second layer
        v2 = tf.round(self.wts['wf'] / (tf.reduce_max(tf.abs(self.wts['wf']))) * (2 ** 1 - 1)) / ((2 ** 1 - 1))


        with tf.control_dependencies([v,v1]):
            self.cOp = [tf.assign(self.wts['w0'], v), tf.assign(self.wts['b0'], v1)]
            self.cOw = [tf.assign(self.wts['wf'], v2)]


        #with tf.control_dependencies([w,w1]):
            #self.cOpw = [tf.assign(self.wts['wf'], w), tf.assign(self.wts['bf'], w1)]


    def encode(self,x):
        w0 = self.wts['w0'] #self.w0
        p0, n0 = tf.maximum(0., w0), tf.maximum(0., -w0)

        #p0 = tf.round(p0/(0.4 * VDD) * (2**2-1)) / ((2**2-1))
        #n0 = tf.round(n0/(0.4 * VDD) * (2**2-1)) / ((2**2-1))

        bmax = tf.stop_gradient(VDD-tf.reduce_sum(tf.abs(w0), axis=0))


        ypb = self.wts['b0'] - tf.reduce_sum(tf.abs(n0), axis=0)
        ypb = tf.clip_by_value(ypb,0.,bmax)
        
        ynb = VDD-self.wts['b0'] - tf.reduce_sum(tf.abs(p0), axis=0)
        ynb = tf.clip_by_value(ynb,0.,bmax)

        yp = tf.matmul(x, p0) + tf.matmul((1-x), n0) + ypb
        yn = tf.matmul((1-x), p0) + tf.matmul(x, n0) + ynb

        yp = activ1(yp-OFFS)-VCM
        yn = activ1(yn-OFFS)-VCM



        wf = self.wts['wf']
        pf,nf = tf.maximum(0.,wf),tf.maximum(0.,-wf)

        #pf = tf.round(pf/(tf.maximum(tf.reduce_max(pf), tf.reduce_max(nf))) * (2**2-1)) / ((2**2-1))
        #nf = tf.round(nf/(tf.maximum(tf.reduce_max(pf), tf.reduce_max(nf))) * (2**2-1)) / ((2**2-1))

        y = tf.matmul(yp,pf) + tf.matmul(yn,nf) + self.wts['bf']

        #return y
        return [activ2(y), activ2L(y)]