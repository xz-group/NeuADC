#!/usr/bin/env python
#-- Ayan Chakrabarti <ayan@wustl.edu>

import sys
import os
import time
import tensorflow as tf
import numpy as np
import ctrlc

import utils as ut
import circuit_sub_ADC as ct
import graytg_sub_ADC_w_r as tg


#########################################################################
# Training Parameters
#########################################################################
BASE_LR = 0.5e-3
SNAPITER = 1
RESETITER = 5e2
maxiter = 4e4
def getlr(iter): ## get learning rate
    if iter < 1e3:
        return BASE_LR
    elif iter < 5e3:
        return 0.5*BASE_LR
    elif iter < 1e4:
        return 0.25*BASE_LR
    elif iter < 1.5e4:
        return 0.1*BASE_LR
    elif iter < 2e4:
        return 0.05*BASE_LR
    else:
        return 0.025*BASE_LR


WD=1e-5
mom = 0.9

bsz = 4096
bgroup = 128

sfreq = 1e3      # How frequently to save
#########################################################################


#########################################################################
# Get params from command line
#########################################################################
if len(sys.argv) != 5:
    sys.exit("USAGE: train.py nBits1 nBits2 Hidden wtdir")
nBits1 = int(sys.argv[1])
nBits2 = int(sys.argv[2])
#nBits3 = int(sys.argv[3])
nHidden = int(sys.argv[3])
#wreso = int(sys.argv[4])
wtdir = sys.argv[4]
#cwt = float(sys.argv[5])
#########################################################################


#########################################################################
# Model save & logging setup
ockp = ut.ckpter(wtdir+'/iter_*.state.npz') # Optimization state
ockp_s = wtdir+'/iter_%d.state.npz'

mckp = ut.ckpter(wtdir+'/iter_*.model.npz') # Model Files
mckp_s = wtdir+'/iter_%d.model.npz'

log = open(wtdir+'/train.log','a')


def mprint(s):
    sys.stdout.write(time.strftime("%Y-%m-%d %H:%M:%S ") + s + "\n")
    log.write(time.strftime("%Y-%m-%d %H:%M:%S ") + s + "\n")
    sys.stdout.flush()
    log.flush()
    
#########################################################################
# Actual model
data = tg.Target(nBits1=nBits1,nBits2=nBits2)
ckt = ct.Circuit(nHidden=nHidden,nBits=nBits2)

gt = tf.placeholder(dtype=tf.float32) ## ground truth
sig = tf.placeholder(dtype=tf.float32) ## input training data

hpred, acl1 = ckt.encode(sig)
#hpred = ckt.encode(sig)

#loss = data.Eval(gt,hpred) ## to determine if the predicted value is matched with ground truth.
loss,err1 = data.Eval(gt,hpred,acl1)

lr = tf.placeholder(dtype=tf.float32)
opt = tf.train.AdamOptimizer(lr,mom) ## define optimizer.
tStep = opt.minimize(loss + WD * (\
                            tf.nn.l2_loss(ckt.wts['w0'])))
rStep = ut.resetopt(opt,ckt.wts)

#########################################################################
# Start TF session (respecting OMP_NUM_THREADS)
# Restore model if necessary

#gopt = tf.GPUOptions(per_process_gpu_memory_fraction=0.25)
gopt = tf.GPUOptions(allow_growth=True)
sess = tf.Session(config=tf.ConfigProto(gpu_options=gopt))
try:
    sess.run(tf.global_variables_initializer())
except:
    sess.run(tf.initialize_all_variables())

if ockp.latest is not None:
    mprint("Loading model")
    ut.netload(ckt,wtdir+'/iter_%d.model.npz'%ockp.iter, sess)
    mprint("Loading state")
    ut.loadopt(opt,ckt.wts,[],wtdir+'/iter_%d.state.npz'%ockp.iter, sess)
    mprint("Done!")

niter = ockp.iter


#########################################################################
# Main training loop

mprint("Starting from Iteration %d" % niter)
while niter < maxiter:

    e1v_a, lv_a = 0., 0.
    for i in range(bgroup):
        #sigs,bits = data.uSamp(bsz)
        sigs, bits = data.rSamp(bsz)
        e1v, lv, _ = sess.run([err1,loss,tStep], feed_dict={gt: bits, sig: sigs, lr: getlr(niter)})
        #w0,b0,w1,b1 = sess.run([ckt.wts['w0'],ckt.wts['b0'],ckt.wts['wf'],ckt.wts['bf']])
        #sq,n0,sn0 = sess.run([ckt.sq,ckt.n0,ckt.sn0])
        e1v_a = e1v_a+e1v
        lv_a = lv_a+lv
        #mprint("[%09d] lr = %.2e, e1v = %.4e, lv = %.4e " % (niter, getlr(niter), e1v, lv))
    e1v_a = e1v_a / bgroup
    lv_a = lv_a / bgroup
    mprint("[%09d] lr = %.2e, Err1 = %.4e, Loss = %.4e" % (niter, getlr(niter), e1v_a, lv_a))
    niter=niter+1
    if niter % RESETITER == 0:
        sess.run(rStep)
    if niter % SNAPITER == 0:
        sess.run(ckt.cOp)# In this step, we update the weight and bias by using with control_dependencies.
        #sess.run(ckt.cOw) # added by me

    if ctrlc.stop:
        break

    if sfreq > 0 and niter % sfreq == 0:
        ut.netsave(ckt,mckp_s%niter,sess)
        ut.saveopt(opt,ckt.wts,[],ockp_s%niter,sess)
        ockp.clean(every=sfreq) ### sfreq = 1000
        mckp.clean(every=sfreq)
        mprint("Saved model and state.")


mprint("Done!")
ut.netsave(ckt,mckp_s%niter,sess)
ut.saveopt(opt,ckt.wts,[],ockp_s%niter,sess)
ockp.clean(every=sfreq)
mckp.clean(every=sfreq)
mprint("Saved model and state.")
log.close()
